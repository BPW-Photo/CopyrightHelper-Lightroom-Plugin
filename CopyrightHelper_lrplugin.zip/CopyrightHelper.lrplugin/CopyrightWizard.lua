--[[
  CopyrightWizard.lua
  Copyright Helper Plugin for Adobe Lightroom Classic

  Guides photographers through US Copyright Office eCO registration,
  pre-filling fields from Lightroom photo metadata.

  Binding strategy: uses LrView.bind { key=, object= } on every widget
  individually. No shorthand, no inherited bind_to_object. This works
  reliably across LR SDK versions 5+.
--]]

local LrApplication     = import 'LrApplication'
local LrBinding         = import 'LrBinding'
local LrDate            = import 'LrDate'
local LrDialogs         = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrHttp            = import 'LrHttp'
local LrPathUtils       = import 'LrPathUtils'
local LrTasks           = import 'LrTasks'
local LrView            = import 'LrView'

-- ============================================================
-- HELPERS
-- ============================================================

local function currentYear()
    return tostring(os.date("%Y"))
end

local function safeFormatDate(lrTimestamp)
    if not lrTimestamp or lrTimestamp == 0 then return "" end
    local ok, result = pcall(function()
        local year, month, day = LrDate.timestampToComponents(lrTimestamp)
        if year and month and day then
            return string.format("%04d-%02d-%02d", year, month, day)
        end
        return ""
    end)
    return (ok and result) or ""
end

local function getPhotosMetadata(catalog)
    local targetPhotos = catalog:getTargetPhotos()
    local results = {}
    for _, photo in ipairs(targetPhotos) do
        table.insert(results, {
            filename    = photo:getFormattedMetadata('fileName')  or "",
            title       = photo:getFormattedMetadata('title')     or "",
            captureDate = safeFormatDate(photo:getRawMetadata('dateTime')),
            creator     = photo:getFormattedMetadata('creator')   or "",
            copyright   = photo:getFormattedMetadata('copyright') or "",
            path        = photo:getRawMetadata('path')            or "",
        })
    end
    return results
end

local function buildInitialState(photos)
    local first          = photos[1] or {}
    local defaultCreator = (first.creator ~= "") and first.creator or ""
    local defaultYear    = currentYear()
    if first.captureDate and #first.captureDate >= 4 then
        defaultYear = first.captureDate:sub(1, 4)
    end
    return {
        isCollection      = (#photos > 1) and "yes" or "no",
        collectionTitle   = "My Photography Collection " .. currentYear(),
        isPublished       = "no",
        publicationYear   = defaultYear,
        publicationNation = "United States",
        creationYear      = defaultYear,
        authorName        = defaultCreator,
        authorIsOrg       = "no",
        orgName           = "",
        anonymous         = "no",
        authorship        = "photograph",
        contactName       = defaultCreator,
        contactEmail      = "",
        contactAddress    = "",
        contactCity       = "",
        contactState      = "",
        contactZip        = "",
        depositMethod     = "upload",
        photoCount        = #photos,
        photos            = photos,
    }
end

-- ============================================================
-- BINDING HELPER
-- Wraps LrView.bind to keep call sites short.
-- Uses the full { key=, object= } form - never the shorthand.
-- ============================================================

local function vbind(key, obj)
    return LrView.bind { key = key, object = obj }
end

-- ============================================================
-- STEP VIEWS
-- ============================================================

local function stepIntro(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Welcome to the Copyright Filing Wizard",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 17,
            title = "This wizard guides you through preparing your US Copyright\n"
                 .. "Office registration (eCO - Electronic Copyright Office).\n\n"
                 .. "It will:\n"
                 .. "  - Read metadata from your selected Lightroom photos\n"
                 .. "  - Help you answer every question on the eCO form\n"
                 .. "  - Generate a summary report to refer to while filing\n"
                 .. "  - Open the eCO website when you are ready\n\n"
                 .. "You have selected " .. tostring(props.photoCount) .. " photo(s).\n\n"
                 .. "IMPORTANT: This plugin helps you PREPARE your filing.\n"
                 .. "The actual registration is done on copyright.gov\n"
                 .. "and a filing fee applies (typically $35-$55).\n\n"
                 .. "Click Next to begin.",
        },
    }
end

local function stepWorkType(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Step 1 of 5 - Type of Work",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            title           = "For photographs the work type is 'Works of the Visual Arts'.\n"
                           .. "Choose whether you are filing a single image or a collection.",
            fill_horizontal = 1,
            height_in_lines = 3,
        },
        f:group_box {
            title           = "Filing Type",
            fill_horizontal = 1,
            f:radio_button {
                title         = "Single photograph  ($35 fee)",
                value         = vbind('isCollection', props),
                checked_value = "no",
            },
            f:radio_button {
                title         = "Collection of photographs - batch filing  (one fee, many photos)",
                value         = vbind('isCollection', props),
                checked_value = "yes",
            },
        },
        f:group_box {
            title           = "Collection Title  (enter even for single photos - used as the work title)",
            fill_horizontal = 1,
            f:edit_field {
                value           = vbind('collectionTitle', props),
                width_in_chars  = 44,
                fill_horizontal = 1,
                immediate       = true,
            },
            f:static_text {
                title = "Example: Wedding Photography 2025 - Smith and Jones",
                font  = "<system/small>",
            },
        },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 4,
            title = "Tip: A collection is the most cost-effective option for photographers.\n"
                 .. "One fee covers many unpublished images from the same year\n"
                 .. "by the same author.",
        },
    }
end

local function stepPublication(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Step 2 of 5 - Publication Status",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 4,
            title = "A photo is 'published' when copies are distributed to the public\n"
                 .. "(e.g. posted publicly online, sold, or printed for distribution).\n"
                 .. "Password-protected client galleries are generally unpublished.",
        },
        f:group_box {
            title           = "Has this work been published?",
            fill_horizontal = 1,
            f:radio_button {
                title         = "No - this work has NOT been published",
                value         = vbind('isPublished', props),
                checked_value = "no",
            },
            f:radio_button {
                title         = "Yes - this work HAS been published",
                value         = vbind('isPublished', props),
                checked_value = "yes",
            },
        },
        f:group_box {
            title           = "Publication Details  (complete if published, otherwise leave as-is)",
            fill_horizontal = 1,
            f:row {
                f:static_text { title = "Year of first publication:", width = 200 },
                f:edit_field {
                    value          = vbind('publicationYear', props),
                    width_in_chars = 8,
                    immediate      = true,
                },
            },
            f:row {
                f:static_text { title = "Nation of first publication:", width = 200 },
                f:edit_field {
                    value          = vbind('publicationNation', props),
                    width_in_chars = 22,
                    immediate      = true,
                },
            },
        },
        f:group_box {
            title           = "Year of Creation",
            fill_horizontal = 1,
            f:row {
                f:static_text { title = "Year photo(s) were created:", width = 200 },
                f:edit_field {
                    value          = vbind('creationYear', props),
                    width_in_chars = 8,
                    immediate      = true,
                },
            },
            f:static_text {
                title = "Pre-filled from your first photo's capture date.",
                font  = "<system/small>",
            },
        },
    }
end

local function stepAuthor(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Step 3 of 5 - Author & Claimant",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 3,
            title = "The author created the work. The claimant owns the copyright now.\n"
                 .. "For most photographers both are the same person - you.",
        },
        f:group_box {
            title           = "Author Information",
            fill_horizontal = 1,
            f:row {
                f:static_text { title = "Author / Photographer name:", width = 210 },
                f:edit_field {
                    value          = vbind('authorName', props),
                    width_in_chars = 26,
                    immediate      = true,
                },
            },
            f:spacer { height = 6 },
            f:row {
                f:static_text { title = "Nature of authorship:", width = 210 },
                f:edit_field {
                    value          = vbind('authorship', props),
                    width_in_chars = 26,
                    immediate      = true,
                },
            },
            f:static_text {
                title = "Enter:  photograph   or   2-D artwork, photograph",
                font  = "<system/small>",
            },
            f:spacer { height = 6 },
            f:row {
                f:static_text { title = "Is the author an organisation?", width = 210 },
                f:radio_button {
                    title         = "No (individual)",
                    value         = vbind('authorIsOrg', props),
                    checked_value = "no",
                },
                f:radio_button {
                    title         = "Yes (company / studio)",
                    value         = vbind('authorIsOrg', props),
                    checked_value = "yes",
                },
            },
            f:row {
                f:static_text { title = "Organisation name (if applicable):", width = 210 },
                f:edit_field {
                    value          = vbind('orgName', props),
                    width_in_chars = 26,
                    immediate      = true,
                },
            },
            f:spacer { height = 6 },
            f:row {
                f:static_text { title = "File anonymously?", width = 210 },
                f:radio_button {
                    title         = "No",
                    value         = vbind('anonymous', props),
                    checked_value = "no",
                },
                f:radio_button {
                    title         = "Yes (anonymous filing)",
                    value         = vbind('anonymous', props),
                    checked_value = "yes",
                },
            },
        },
    }
end

local function stepContact(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Step 4 of 5 - Contact & Correspondence",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 3,
            title = "The Copyright Office uses this to contact you if questions arise\n"
                 .. "and to mail your registration certificate.",
        },
        f:group_box {
            title           = "Contact Details",
            fill_horizontal = 1,
            f:row {
                f:static_text { title = "Full name:",      width = 130 },
                f:edit_field  {
                    value           = vbind('contactName', props),
                    width_in_chars  = 30,
                    fill_horizontal = 1,
                    immediate       = true,
                },
            },
            f:row {
                f:static_text { title = "Email address:",  width = 130 },
                f:edit_field  {
                    value           = vbind('contactEmail', props),
                    width_in_chars  = 30,
                    fill_horizontal = 1,
                    immediate       = true,
                },
            },
            f:row {
                f:static_text { title = "Street address:", width = 130 },
                f:edit_field  {
                    value           = vbind('contactAddress', props),
                    width_in_chars  = 30,
                    fill_horizontal = 1,
                    immediate       = true,
                },
            },
            f:row {
                f:static_text { title = "City:",           width = 130 },
                f:edit_field  {
                    value          = vbind('contactCity', props),
                    width_in_chars = 20,
                    immediate      = true,
                },
            },
            f:row {
                f:static_text { title = "State / Region:", width = 130 },
                f:edit_field  {
                    value          = vbind('contactState', props),
                    width_in_chars = 12,
                    immediate      = true,
                },
            },
            f:row {
                f:static_text { title = "ZIP / Postcode:", width = 130 },
                f:edit_field  {
                    value          = vbind('contactZip', props),
                    width_in_chars = 12,
                    immediate      = true,
                },
            },
        },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 2,
            title = "Note: On the eCO site fill in Individual OR Organisation - not both.",
        },
    }
end

local function stepDeposit(f, props)
    return f:column {
        fill_horizontal = 1,
        spacing = f:dialog_spacing(),
        f:static_text {
            title           = "Step 5 of 5 - Deposit Copy Strategy",
            font            = "<system/bold>",
            fill_horizontal = 1,
        },
        f:separator { fill_horizontal = 1 },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 3,
            title = "You must submit a deposit copy of your work with the application.\n"
                 .. "For photographs this is a digital file (JPEG/TIFF) or physical print.",
        },
        f:group_box {
            title           = "Submission Method",
            fill_horizontal = 1,
            f:radio_button {
                title         = "Upload digitally via the eCO website  (recommended)",
                value         = vbind('depositMethod', props),
                checked_value = "upload",
            },
            f:static_text {
                font            = "<system/small>",
                fill_horizontal = 1,
                height_in_lines = 3,
                title = "JPEG or TIFF accepted. Upload as individual files or a ZIP.\n"
                     .. "Each upload session handles up to 500 MB.\n"
                     .. "Best practice: 600-800px long side JPEG, sRGB colour space.",
            },
            f:spacer { height = 8 },
            f:radio_button {
                title         = "Mail a physical print or disc",
                value         = vbind('depositMethod', props),
                checked_value = "mail",
            },
            f:static_text {
                font            = "<system/small>",
                fill_horizontal = 1,
                height_in_lines = 3,
                title = "US Copyright Office, 101 Independence Ave SE, Washington DC 20559.\n"
                     .. "Include a printed copy of your online submission confirmation.\n"
                     .. "Note: mail processing takes significantly longer than digital.",
            },
        },
        f:static_text {
            fill_horizontal = 1,
            height_in_lines = 5,
            title = "When you click Finish & Open eCO, this wizard will:\n"
                 .. "  1. Save a summary report to your Desktop\n"
                 .. "  2. Open the US Copyright Office eCO website in your browser\n"
                 .. "  3. You use the report as a reference while you complete the form",
        },
    }
end

-- ============================================================
-- REPORT GENERATOR
-- ============================================================

local function generateReport(props)
    local lines = {}
    local function add(s) lines[#lines + 1] = s end

    add("========================================")
    add("  COPYRIGHT FILING SUMMARY REPORT")
    add("  Generated: " .. os.date("%Y-%m-%d %H:%M"))
    add("========================================\n")
    add("STEP 1 - TYPE OF WORK")
    add("  Work type:        Works of the Visual Arts (Photograph)")
    if props.isCollection == "yes" then
        add("  Filing type:      Collection")
        add("  Collection title: " .. (props.collectionTitle or ""))
    else
        add("  Filing type:      Single Work")
        add("  Title:            " .. (props.collectionTitle or ""))
    end
    add("  Number of photos: " .. tostring(props.photoCount))
    add("")
    add("STEP 2 - PUBLICATION STATUS")
    if props.isPublished == "yes" then
        add("  Published:        Yes")
        add("  Year published:   " .. (props.publicationYear   or ""))
        add("  Nation:           " .. (props.publicationNation or ""))
    else
        add("  Published:        No (unpublished)")
    end
    add("  Year created:     " .. (props.creationYear or ""))
    add("")
    add("STEP 3 - AUTHOR & CLAIMANT")
    add("  Author name:      " .. (props.authorName  or ""))
    add("  Nature of auth.:  " .. (props.authorship  or ""))
    if props.authorIsOrg == "yes" then
        add("  Organisation:     " .. (props.orgName or ""))
    end
    add("  Anonymous:        " .. (props.anonymous == "yes" and "Yes" or "No"))
    add("")
    add("STEP 4 - CONTACT / CORRESPONDENCE")
    add("  Name:    " .. (props.contactName    or ""))
    add("  Email:   " .. (props.contactEmail   or ""))
    add("  Address: " .. (props.contactAddress or ""))
    add("  City:    " .. (props.contactCity    or ""))
    add("  State:   " .. (props.contactState   or ""))
    add("  ZIP:     " .. (props.contactZip     or ""))
    add("")
    add("STEP 5 - DEPOSIT METHOD")
    if props.depositMethod == "upload" then
        add("  Method: Digital upload via eCO website")
    else
        add("  Method: Mail physical deposit")
    end
    add("")
    add("========================================")
    add("  INCLUDED PHOTOS  (" .. tostring(props.photoCount) .. " total)")
    add("========================================")
    for i, photo in ipairs(props.photos or {}) do
        add(string.format("  [%d] %s", i, photo.filename))
        if photo.captureDate ~= "" then add("      Captured: " .. photo.captureDate) end
        if photo.title       ~= "" then add("      Title:    " .. photo.title)       end
    end
    add("")
    add("========================================")
    add("  eCO FILING CHECKLIST")
    add("========================================")
    add("  [ ] Log in at: https://www.copyright.gov/eco/")
    add("  [ ] Click 'Register a New Claim'")
    add("  [ ] Answer the 3 yes/no screening questions")
    add("  [ ] Type of Work: Works of the Visual Arts")
    add("  [ ] Enter work / collection title (see above)")
    add("  [ ] Enter publication status (see above)")
    add("  [ ] Enter author name and nature of authorship (see above)")
    add("  [ ] Enter claimant (same as author unless copyright was transferred)")
    add("  [ ] Enter contact / correspondence details (see above)")
    add("  [ ] Enter mailing address for your certificate")
    add("  [ ] Skip Special Handling unless you have an urgent legal deadline")
    add("  [ ] Review, certify, and add to cart")
    add("  [ ] Pay the filing fee (credit card or deposit account)")
    add("  [ ] Upload or mail your deposit copy")
    add("  [ ] Save your case number to track status")
    add("")
    add("  Typical fee:     $35 (single image, 1 author) to $55 (standard)")
    add("  Processing time: ~8 months online  /  ~13 months paper")
    add("")
    add("  Check status: https://www.copyright.gov/eco/")
    add("")
    add("========================================")
    add("  Copyright Helper Plugin by Rob Durston")
    add("  If this tool helped you, please consider donating to Lucy's Trust:")
    add("  International: paypal.me/lucystrust")
    add("  UK:            justgiving.com/charity/lucystrust")
    add("========================================")
    add("")
    return table.concat(lines, "\n")
end

-- ============================================================
-- MAIN WIZARD RUNNER
-- ============================================================

LrTasks.startAsyncTask(function()
    LrFunctionContext.callWithContext("CopyrightWizard", function(context)

        local catalog = LrApplication.activeCatalog()
        local photos  = getPhotosMetadata(catalog)

        if #photos == 0 then
            LrDialogs.message(
                "Copyright Helper",
                "No photos are selected. Please select at least one photo and try again.",
                "warning"
            )
            return
        end

        local f     = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)

        -- Seed properties
        for k, v in pairs(buildInitialState(photos)) do
            props[k] = v
        end

        local steps = {
            { title = "Introduction",       view = stepIntro       },
            { title = "Type of Work",       view = stepWorkType    },
            { title = "Publication Status", view = stepPublication },
            { title = "Author & Claimant",  view = stepAuthor      },
            { title = "Contact Details",    view = stepContact     },
            { title = "Deposit Strategy",   view = stepDeposit     },
        }

        local currentStep = 1
        local running     = true

        while running do
            local step       = steps[currentStep]
            local totalSteps = #steps - 1
            local label      = (currentStep == 1)
                and "Introduction"
                or  string.format("Step %d of %d - %s", currentStep - 1, totalSteps, step.title)

            local isLast  = (currentStep == #steps)
            local isFirst = (currentStep == 1)

            local result = LrDialogs.presentModalDialog {
                title     = "Copyright Filing Wizard - " .. label,
                resizable = false,
                contents  = f:column {
                    bind_to_object  = props,
                    spacing         = f:dialog_spacing(),
                    fill_horizontal = 1,
                    width           = 520,
                    step.view(f, props),
                },
                actionVerb = isLast  and "Finish & Open eCO" or "Next",
                cancelVerb = isFirst and "Cancel"            or "Back",
            }

            if result == "ok" then
                if not isLast then
                    currentStep = currentStep + 1
                else
                    -- Save report to Desktop and open browser
                    local report     = generateReport(props)
                    local desktop    = LrPathUtils.getStandardFilePath("desktop")
                    local stamp      = os.date("%Y%m%d_%H%M")
                    local reportPath = LrPathUtils.child(desktop, "CopyrightFilingReport_" .. stamp .. ".txt")

                    local fh = io.open(reportPath, "w")
                    if fh then
                        fh:write(report)
                        fh:close()
                        LrDialogs.message(
                            "Report Saved - Ready to File",
                            "Your filing summary has been saved to your Desktop:\n"
                             .. reportPath
                             .. "\n\nThe US Copyright Office eCO website will now open.\n"
                             .. "Keep the report open alongside your browser as you fill in the form.",
                            "info"
                        )
                    else
                        LrDialogs.message(
                            "Could Not Save Report",
                            "The report could not be saved to your Desktop. "
                             .. "The eCO website will still open - please note your details manually.",
                            "warning"
                        )
                    end

                    LrHttp.openUrlInBrowser("https://www.copyright.gov/eco/")
                    running = false
                end
            elseif result == "cancel" then
                if not isFirst then
                    currentStep = currentStep - 1   -- Back button
                else
                    running = false                  -- Cancel at intro
                end
            else
                running = false
            end
        end

    end)
end)
