return {

    LrSdkVersion = 6.0,
    LrSdkMinimumVersion = 5.0,

    LrToolkitIdentifier = 'com.photographer.lightroom.copyrighthelper',

    LrPluginName = "Copyright Helper",

    LrPluginInfoUrl = "https://copyright.gov/eco/",

    LrLibraryMenuItems = {
        {
            title = "Copyright Filing Assistant...",
            file = "CopyrightWizard.lua",
            enabledWhen = "photosAvailable",
        },
        {
            title = "Apply Copyright Metadata to Selected Photos",
            file = "ApplyCopyrightMetadata.lua",
            enabledWhen = "photosSelected",
        },
        {
            title = "Export Copyright Title List (CSV)...",
            file = "ExportCopyrightReport.lua",
            enabledWhen = "photosAvailable",
        },
    },

    VERSION = {
        major = 1,
        minor = 0,
        revision = 0,
        build = 1,
        display = "1.0.0",
    },
}
