--[[
  ExportCopyrightReport.lua
  Copyright Helper Plugin for Adobe Lightroom Classic

  Generates the official US Copyright Office title list CSV AND
  optionally exports low-resolution deposit copies of the selected photos,
  all to a folder of the user's choosing.

  CSV format per Copyright Office requirements:
    Row 1: "This is the Complete List of Photographs for Case Number 1-#######"
    Row 2: "Title of Group: GroupName_Case_Number_1-#######"
    Row 3: Column headers
    Rows 4+: Sequence Number, Title of Photograph, File Name

  CSV filename format: [Group Name] Case Number 1-XXXXXXXXXX.csv
--]]

local LrApplication     = import 'LrApplication'
local LrBinding         = import 'LrBinding'
local LrDialogs         = import 'LrDialogs'
local LrExportSession   = import 'LrExportSession'
local LrFileUtils       = import 'LrFileUtils'
local LrFunctionContext = import 'LrFunctionContext'
local LrPathUtils       = import 'LrPathUtils'
local LrProgressScope   = import 'LrProgressScope'
local LrShell           = import 'LrShell'
local LrTasks           = import 'LrTasks'
local LrView            = import 'LrView'

local function vbind(key, obj)
    return LrView.bind { key = key, object = obj }
end

local function csvEscape(s)
    if not s then return '""' end
    s = tostring(s):gsub('"', '""')
    return '"' .. s .. '"'
end

-- ============================================================
-- EXPORT DIALOG
-- ============================================================

LrTasks.startAsyncTask(function()
    LrFunctionContext.callWithContext("ExportCopyrightReport", function(context)

        local catalog      = LrApplication.activeCatalog()
        local f            = LrView.osFactory()
        local props        = LrBinding.makePropertyTable(context)
        local targetPhotos = catalog:getTargetPhotos()

        if #targetPhotos == 0 then
            LrDialogs.message(
                "Copyright Helper",
                "No photos are selected.\n\nPlease select the photos you want to register and try again.",
                "warning"
            )
            return
        end

        -- ---- Default property values ----
        local today = os.date("%m%d%Y")
        props.groupTitle      = "PhotographerName-JobDetails_" .. today
        props.hasCaseNumber   = "no"         -- "yes" or "no"
        props.caseNumber      = ""
        props.exportImages    = true
        props.pixelChoice     = "600"        -- "600", "800", "custom"
        props.customPx        = "700"
        props.saveFolder      = LrPathUtils.getStandardFilePath("desktop")
        props.openAfter       = true

        -- ---- Build dialog ----
        local result = LrDialogs.presentModalDialog {
            title    = "Export Copyright Title List  (" .. #targetPhotos .. " photos)",
            contents = f:column {
                bind_to_object  = props,
                spacing         = f:dialog_spacing(),
                width           = 530,

                -- Header
                f:static_text {
                    fill_horizontal = 1,
                    height_in_lines = 3,
                    title = "Creates the official Copyright Office title list (CSV) for your\n"
                         .. "group registration, and optionally exports low-res deposit images,\n"
                         .. "all saved to a folder of your choice.",
                },
                f:separator { fill_horizontal = 1 },

                -- GROUP TITLE
                f:group_box {
                    title           = "Group Title",
                    fill_horizontal = 1,
                    f:static_text {
                        title           = "Recommended format:  PhotographerName-JobDetails_MMDDYYYY",
                        font            = "<system/small>",
                        fill_horizontal = 1,
                    },
                    f:static_text {
                        title = "Example:  JaneSmith-WeddingJonesFamily_06152025",
                        font  = "<system/small>",
                    },
                    f:spacer { height = 4 },
                    f:edit_field {
                        value           = vbind('groupTitle', props),
                        width_in_chars  = 52,
                        fill_horizontal = 1,
                        immediate       = true,
                    },
                },

                -- CASE NUMBER
                f:group_box {
                    title           = "Case Number",
                    fill_horizontal = 1,

                    f:static_text {
                        fill_horizontal = 1,
                        height_in_lines = 2,
                        title = "Your case number is shown at the top of each screen in the eCO\n"
                             .. "application (format: 1-1234567890).",
                    },
                    f:spacer { height = 4 },

                    f:radio_button {
                        title          = "I have my case number:",
                        value          = vbind('hasCaseNumber', props),
                        checked_value  = "yes",
                    },
                    f:row {
                        f:spacer { width = 20 },
                        f:edit_field {
                            value          = vbind('caseNumber', props),
                            width_in_chars = 20,
                            immediate      = true,
                            enabled        = vbind('hasCaseNumber', props),
                        },
                        f:static_text {
                            title = "  e.g. 1-1234567890",
                            font  = "<system/small>",
                        },
                    },
                    f:spacer { height = 4 },
                    f:radio_button {
                        title          = "I don't have a case number yet - I'll fill it in manually later",
                        value          = vbind('hasCaseNumber', props),
                        checked_value  = "no",
                    },
                    f:static_text {
                        title = "      The CSV and folder will use PLACEHOLDER. Rename them\n"
                             .. "      once you have your case number from the eCO website.",
                        font  = "<system/small>",
                        fill_horizontal = 1,
                        height_in_lines = 2,
                    },
                },

                -- IMAGE EXPORT
                f:group_box {
                    title           = "Export Deposit Images",
                    fill_horizontal = 1,

                    f:checkbox {
                        title = "Also export low-resolution JPEG deposit copies of the selected photos",
                        value = vbind('exportImages', props),
                    },
                    f:spacer { height = 4 },

                    f:static_text {
                        title = "The Copyright Office does not require full resolution.\n"
                             .. "600-800px on the long side is standard practice and protects your originals.",
                        font            = "<system/small>",
                        fill_horizontal = 1,
                        height_in_lines = 2,
                    },
                    f:spacer { height = 6 },

                    f:row {
                        f:static_text { title = "Long side pixel size:", width = 150 },
                        f:radio_button {
                            title          = "600px",
                            value          = vbind('pixelChoice', props),
                            checked_value  = "600",
                        },
                        f:radio_button {
                            title          = "800px",
                            value          = vbind('pixelChoice', props),
                            checked_value  = "800",
                        },
                        f:radio_button {
                            title          = "Custom:",
                            value          = vbind('pixelChoice', props),
                            checked_value  = "custom",
                        },
                        f:edit_field {
                            value          = vbind('customPx', props),
                            width_in_chars = 6,
                            immediate      = true,
                        },
                        f:static_text { title = "px" },
                    },
                    f:static_text {
                        title = "Images are exported as JPEG, sRGB, quality 80. Filenames are unchanged.",
                        font  = "<system/small>",
                    },
                },

                -- SAVE LOCATION
                f:group_box {
                    title           = "Save Location",
                    fill_horizontal = 1,
                    f:static_text {
                        title = "All files (CSV title list and images) will be saved into a\n"
                             .. "new subfolder named after your group title.",
                        font            = "<system/small>",
                        fill_horizontal = 1,
                        height_in_lines = 2,
                    },
                    f:spacer { height = 4 },
                    f:row {
                        f:static_text {
                            title           = "Save in:",
                            width           = 60,
                        },
                        f:static_text {
                            value           = vbind('saveFolder', props),
                            fill_horizontal = 1,
                            font            = "<system/small>",
                        },
                    },
                    f:spacer { height = 4 },
                    f:push_button {
                        title  = "Choose Folder...",
                        action = function()
                            local chosen = LrDialogs.runOpenPanel {
                                title                = "Choose where to save your copyright files",
                                canChooseFiles       = false,
                                canChooseDirectories = true,
                                allowsMultipleSelection = false,
                                initialDirectory     = props.saveFolder,
                            }
                            if chosen and chosen[1] then
                                props.saveFolder = chosen[1]
                            end
                        end,
                    },
                },

                f:row {
                    f:checkbox {
                        title = "Open the export folder when done",
                        value = vbind('openAfter', props),
                    },
                },
            },
            actionVerb = "Export",
        }

        if result ~= "ok" then return end

        -- ---- Resolve case number ----
        local caseNum
        if props.hasCaseNumber == "yes" and props.caseNumber ~= "" then
            caseNum = props.caseNumber:gsub('%s+', '')
            -- Ensure it starts with 1- 
            if not caseNum:match("^1%-") then
                caseNum = "1-" .. caseNum
            end
        else
            caseNum = "1-PLACEHOLDER"
        end

        -- ---- Sanitise group title for folder and filename ----
        local safeTitle = (props.groupTitle or "Group"):gsub('[/\\:*?"<>|]', '-')

        -- ---- Create output subfolder ----
        local outputFolder = LrPathUtils.child(props.saveFolder, safeTitle .. " Case Number " .. caseNum)
        LrFileUtils.createAllDirectories(outputFolder)

        -- ---- Write CSV title list ----
        local csvName    = safeTitle .. " Case Number " .. caseNum .. ".csv"
        local csvPath    = LrPathUtils.child(outputFolder, csvName)

        local row1 = "This is the Complete List of Photographs for Case Number " .. caseNum
        local row2 = "Title of Group: " .. (props.groupTitle or "") .. "_Case_Number_" .. caseNum

        local csvProgress = LrProgressScope {
            title     = "Writing copyright title list...",
            canCancel = false,
        }

        local fh = io.open(csvPath, "w")
        if not fh then
            csvProgress:done()
            LrDialogs.message("Copyright Helper", "Could not write CSV to:\n" .. csvPath, "critical")
            return
        end

        fh:write(csvEscape(row1) .. "\n")
        fh:write(csvEscape(row2) .. "\n")
        fh:write(table.concat({
            csvEscape("Sequence Number"),
            csvEscape("Title of Photograph"),
            csvEscape("File Name"),
        }, ",") .. "\n")

        for i, photo in ipairs(targetPhotos) do
            local filename = photo:getFormattedMetadata('fileName') or ""
            local title    = photo:getFormattedMetadata('title')    or ""
            if title == "" then
                title = filename:match("^(.+)%..+$") or filename
            end
            fh:write(table.concat({
                csvEscape(tostring(i)),
                csvEscape(title),
                csvEscape(filename),
            }, ",") .. "\n")
        end

        fh:close()
        csvProgress:done()

        -- ---- Optionally export images ----
        if props.exportImages then

            -- Resolve pixel size
            local longSide = 600
            if props.pixelChoice == "800" then
                longSide = 800
            elseif props.pixelChoice == "custom" then
                longSide = tonumber(props.customPx) or 600
                if longSide < 100 then longSide = 100 end
                if longSide > 9999 then longSide = 9999 end
            end

            local imageFolder = LrPathUtils.child(outputFolder, "deposit_images")
            LrFileUtils.createAllDirectories(imageFolder)

            local exportSettings = {
                LR_collisionHandling        = "rename",
                LR_export_destinationType   = "specificFolder",
                LR_export_destinationPathPrefix = imageFolder,
                LR_export_useSubfolder      = false,
                LR_format                   = "JPEG",
                LR_jpeg_quality             = 0.8,
                LR_jpeg_useLimitSize        = false,
                LR_minimizeEmbeddedMetadata = false,
                LR_outputSharpeningOn       = false,
                LR_size_doConstrain         = true,
                LR_size_maxHeight           = longSide,
                LR_size_maxWidth            = longSide,
                LR_size_resizeType          = "longEdge",
                LR_size_units               = "pixels",
                LR_useWatermark             = false,
                LR_colorspace               = "sRGB",
                LR_reimportExportedPhoto    = false,
            }

            local exportSession = LrExportSession {
                photosToExport = targetPhotos,
                exportSettings = exportSettings,
            }

            local imgProgress = LrProgressScope {
                title    = "Exporting " .. #targetPhotos .. " deposit image(s)...",
                canCancel = true,
            }

            local exportCount = 0
            for _, rendition in exportSession:renditions() do
                if imgProgress:isCanceled() then break end
                local success, pathOrMessage = rendition:waitForRender()
                if success then
                    exportCount = exportCount + 1
                end
                imgProgress:setPortionComplete(exportCount, #targetPhotos)
            end

            imgProgress:done()
        end

        -- ---- Open folder / finish ----
        if props.openAfter then
            LrShell.revealInShell(outputFolder)
        end

        local imageNote = props.exportImages
            and "\n\nDeposit images saved in:\n" .. LrPathUtils.child(outputFolder, "deposit_images")
            or  ""

        local caseNote = (props.hasCaseNumber == "no")
            and "\n\nRemember to rename the folder and CSV with your actual case number\nonce you have it from the eCO website."
            or  ""

        LrDialogs.message(
            "Export Complete",
            #targetPhotos .. " photo(s) listed in title list:\n"
             .. csvPath
             .. imageNote
             .. caseNote,
            "info"
        )

    end)
end)
