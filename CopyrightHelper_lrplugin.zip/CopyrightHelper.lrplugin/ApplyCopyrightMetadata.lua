--[[
  ApplyCopyrightMetadata.lua
  Copyright Helper Plugin for Adobe Lightroom Classic

  Applies standardised IPTC copyright metadata to all selected photos.
--]]

local LrApplication     = import 'LrApplication'
local LrBinding         = import 'LrBinding'
local LrDialogs         = import 'LrDialogs'
local LrFunctionContext = import 'LrFunctionContext'
local LrProgressScope   = import 'LrProgressScope'
local LrTasks           = import 'LrTasks'
local LrView            = import 'LrView'

local function vbind(key, obj)
    return LrView.bind { key = key, object = obj }
end

LrTasks.startAsyncTask(function()
    LrFunctionContext.callWithContext("ApplyCopyrightMetadata", function(context)

        local catalog = LrApplication.activeCatalog()
        local photos  = catalog:getTargetPhotos()

        if #photos == 0 then
            LrDialogs.message(
                "Copyright Helper",
                "No photos are selected. Please select photos in the Grid or Filmstrip first.",
                "warning"
            )
            return
        end

        local f     = LrView.osFactory()
        local props = LrBinding.makePropertyTable(context)

        -- Pre-fill from first photo's existing metadata
        local first = photos[1]
        props.copyrightNotice = first:getFormattedMetadata('copyright')        or ""
        props.creator         = first:getFormattedMetadata('creator')          or ""
        props.creatorUrl      = first:getFormattedMetadata('creatorUrl')       or ""
        props.rightsUsage     = first:getFormattedMetadata('rightsUsageTerms') or "All rights reserved"
        props.copyrightStatus = "copyrighted"

        if props.copyrightNotice == "" then
            local year = tostring(os.date("%Y"))
            local name = (props.creator ~= "") and props.creator or "[Your Name]"
            props.copyrightNotice = "Copyright " .. year .. " " .. name .. ". All rights reserved."
        end

        local result = LrDialogs.presentModalDialog {
            title     = "Apply Copyright Metadata to " .. #photos .. " Photo(s)",
            resizable = false,
            contents  = f:column {
                bind_to_object  = props,
                spacing         = f:dialog_spacing(),
                width           = 500,

                f:static_text {
                    title = "This will write IPTC copyright fields to all "
                         .. #photos .. " selected photo(s).\n"
                         .. "Existing copyright values will be overwritten.",
                    fill_horizontal = 1,
                    height_in_lines = 3,
                },
                f:separator { fill_horizontal = 1 },

                f:group_box {
                    title           = "Copyright Information",
                    fill_horizontal = 1,

                    f:row {
                        f:static_text { title = "Copyright Notice:", width = 160 },
                        f:edit_field {
                            value           = vbind('copyrightNotice', props),
                            width_in_chars  = 34,
                            fill_horizontal = 1,
                            immediate       = true,
                        },
                    },
                    f:static_text {
                        title = "Example: Copyright 2025 Jane Smith. All rights reserved.",
                        font  = "<system/small>",
                    },

                    f:spacer { height = 6 },

                    f:row {
                        f:static_text { title = "Copyright Status:", width = 160 },
                        f:popup_menu {
                            value = vbind('copyrightStatus', props),
                            items = {
                                { title = "Copyrighted",  value = "copyrighted"  },
                                { title = "Public Domain", value = "publicDomain" },
                                { title = "Unknown",       value = "unknown"      },
                            },
                        },
                    },

                    f:spacer { height = 6 },

                    f:row {
                        f:static_text { title = "Creator / Photographer:", width = 160 },
                        f:edit_field {
                            value           = vbind('creator', props),
                            width_in_chars  = 28,
                            fill_horizontal = 1,
                            immediate       = true,
                        },
                    },

                    f:spacer { height = 6 },

                    f:row {
                        f:static_text { title = "Creator URL / Website:", width = 160 },
                        f:edit_field {
                            value           = vbind('creatorUrl', props),
                            width_in_chars  = 28,
                            fill_horizontal = 1,
                            immediate       = true,
                        },
                    },

                    f:spacer { height = 6 },

                    f:row {
                        f:static_text { title = "Rights & Usage Terms:", width = 160 },
                        f:edit_field {
                            value           = vbind('rightsUsage', props),
                            width_in_chars  = 28,
                            fill_horizontal = 1,
                            immediate       = true,
                        },
                    },
                    f:static_text {
                        title = "Example: All rights reserved. No reproduction without written permission.",
                        font  = "<system/small>",
                    },
                },

                f:static_text {
                    title = "Tip: Embedding copyright metadata in your files is good practice\n"
                         .. "even without formal registration - it travels with the image file.",
                    fill_horizontal = 1,
                    height_in_lines = 3,
                },
            },
            actionVerb = "Apply to " .. #photos .. " Photo(s)",
        }

        if result ~= "ok" then return end

        local progress = LrProgressScope {
            title    = "Applying copyright metadata...",
            caption  = "",
            canCancel = true,
        }

        catalog:withWriteAccessDo("Apply Copyright Metadata", function()
            for i, photo in ipairs(photos) do
                if progress:isCanceled() then break end
                progress:setCaption(photo:getFormattedMetadata('fileName'))
                progress:setPortionComplete(i, #photos)

                photo:setRawMetadata('copyright',        props.copyrightNotice)
                photo:setRawMetadata('copyrightState',   props.copyrightStatus)
                photo:setRawMetadata('creator',          props.creator)
                photo:setRawMetadata('creatorUrl',       props.creatorUrl)
                photo:setRawMetadata('rightsUsageTerms', props.rightsUsage)
            end
        end)

        progress:done()

        LrDialogs.message(
            "Copyright Metadata Applied",
            string.format(
                "Copyright metadata written to %d photo(s).\n\nCopyright: %s\nCreator: %s",
                #photos, props.copyrightNotice, props.creator
            ),
            "info"
        )

    end)
end)
